This software is distributed under the following license.

---

APACHE 2 LICENSE

LabWarden
AppWarden
ConsoleUserWarden
MountWarden
NetworkStatusWarden
SleepWarden

dockutil

---

GNU LICENSE

rsync

---

MIT LICENSE

mysides

---



