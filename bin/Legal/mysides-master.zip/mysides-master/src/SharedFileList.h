#import <Foundation/Foundation.h>

@interface SharedFileList : NSObject

@end
