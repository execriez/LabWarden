# NetworkStateWarden
Run custom code when the network state changes on OS X.

##Description:

NetworkStateWarden catches OSX network state changes, to allow you to run custom code when the network goes down, or comes up.

It consists of the following components:

	NetworkStateWarden             - The main binary that catches the network change events
	NetworkStateWarden-NetworkDown - Called when the network goes down
	NetworkStateWarden-NetworkUp   - Called when the network comes up

The example NetworkStateWarden-NetworkDown and NetworkStateWarden-NetworkUp are bash scripts.

The example scripts simply use the "say" command to let you know when the network is up or down. You should customise these scripts to your own needs.


##How to install:

1. Download and unzip the software to a convenient location.
2. Double click the file "Install.command"
3. Reboot

##How to uninstall:

1. Delete the following files and folders

		/usr/local/NetworkStateWarden
		/Library/LaunchDaemons/com.github.execriez.NetworkStateWarden.Example.plist
	
2. Reboot

##History:

1.0.1 - 02 JUN 2016

* First public release.
