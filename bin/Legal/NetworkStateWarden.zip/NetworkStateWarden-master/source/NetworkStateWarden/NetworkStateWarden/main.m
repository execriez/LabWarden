//
//  main.m
//  NetworkStateWarden
//  Version 1.0.1
//
//  Created on 02/06/2016 by Mark J Swift by googling example code.
//
//  Calls an external commands via bash when network state changes between up and down
//  External commands are NetworkStateWarden-NetworkUp and NetworkStateWarden-NetworkDown

#import <Foundation/Foundation.h>
#import <SystemConfiguration/SystemConfiguration.h>

@interface NSString (ShellExecution)
- (NSString*)runAsCommand;
@end

@implementation NSString (ShellExecution)

- (NSString*)runAsCommand {
    NSPipe* pipe = [NSPipe pipe];
    
    NSTask* task = [[NSTask alloc] init];
    [task setLaunchPath: @"/bin/sh"];
    [task setArguments:@[@"-c", [NSString stringWithFormat:@"%@", self]]];
    [task setStandardOutput:pipe];
    
    NSFileHandle* file = [pipe fileHandleForReading];
    [task launch];
    
    return [[NSString alloc] initWithData:[file readDataToEndOfFile] encoding:NSUTF8StringEncoding];
}

@end

SCDynamicStoreRef session;

void NetworkStateCallback(SCDynamicStoreRef store, CFArrayRef changedKeys, void *info)
{
    CFIndex         i;
    CFIndex         count;
    CFStringRef		state_network_global_ipv4_key = NULL;
    
    state_network_global_ipv4_key = SCDynamicStoreKeyCreate(NULL, CFSTR("%@/%@/%@/%@"), kSCDynamicStoreDomainState, kSCCompNetwork, kSCCompGlobal, kSCEntNetIPv4);
    
    NSString * exepath = [[NSBundle mainBundle] executablePath];
    
    count = CFArrayGetCount(changedKeys);
    for (i=0; i < count; i++) {
        CFStringRef keyName = CFArrayGetValueAtIndex(changedKeys, i);
        CFPropertyListRef KeyProp = SCDynamicStoreCopyValue(store, (CFStringRef) keyName);
        
        if (CFStringCompare(keyName, state_network_global_ipv4_key, 0) == kCFCompareEqualTo) {
            
            if (KeyProp) {
                NSLog(@"Network Service up");
                [[NSString stringWithFormat:@"%@-NetworkUp", exepath] runAsCommand];
                
            } else {
                NSLog(@"Network Service down");
                [[NSString stringWithFormat:@"%@-NetworkDown", exepath] runAsCommand];
                
            }
            
            continue;
        }
    }
    
    CFRelease(state_network_global_ipv4_key);
    
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        CFStringRef         key;
        CFMutableArrayRef	keys = NULL;
        CFMutableArrayRef	patterns = NULL;
        CFRunLoopSourceRef	rls;
        
        SCDynamicStoreContext context = {0, NULL, NULL, NULL, NULL};
        session = SCDynamicStoreCreate(NULL, CFSTR("NetworkStateWarden"), NetworkStateCallback, &context);

        keys = CFArrayCreateMutable(NULL, 0, &kCFTypeArrayCallBacks);
        patterns = CFArrayCreateMutable(NULL, 0, &kCFTypeArrayCallBacks);

        // Key to track changes to State:/Network/Global/IPv4
        
        key = SCDynamicStoreKeyCreate(NULL, CFSTR("%@/%@/%@/%@"), kSCDynamicStoreDomainState, kSCCompNetwork, kSCCompGlobal, kSCEntNetIPv4);
        
        CFArrayAppendValue(keys, key);
        CFRelease(key);
        
        // If we were tracking changes via patterns, we would do something like this:
        
        /* Pattern to track changes to State,/Network/Interface/[^/]+/Link */
        //key = SCDynamicStoreKeyCreate(NULL, CFSTR("%@/%@/%@/%@/%@"), kSCDynamicStoreDomainState, kSCCompNetwork, kSCCompInterface, kSCCompAnyRegex, kSCEntNetLink);

        //CFArrayAppendValue(patterns, key);
        //CFRelease(key);
        
        SCDynamicStoreSetNotificationKeys(session, keys, patterns);
        CFRelease(keys);
        CFRelease(patterns);
        
        rls = SCDynamicStoreCreateRunLoopSource(NULL, session, 0);
        CFRunLoopAddSource(CFRunLoopGetCurrent(), rls, kCFRunLoopCommonModes);
        CFRelease(rls);

        // Run the RunLoop
        
        CFRunLoopRun();
        
    }
    return 0;
}
